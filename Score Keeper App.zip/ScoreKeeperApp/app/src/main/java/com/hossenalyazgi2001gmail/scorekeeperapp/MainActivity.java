package com.hossenalyazgi2001gmail.scorekeeperapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    public void reload(View view) {
        TextView rightScoreCount = (TextView) findViewById(R.id.RightScoreCounter);
        TextView rightFoulCount = (TextView) findViewById(R.id.RightFoulCounter);
        TextView leftScoreCount = (TextView) findViewById(R.id.LeftScoreCounter);
        TextView leftFoulCount = (TextView) findViewById(R.id.LeftFoulCounter);
        rightScore = 0;
        rightFoul = 0;
        leftScore = 0;
        leftFoul = 0;

        leftScoreCount.setText("" + leftScore);
        rightScoreCount.setText("" + rightScore);
        rightFoulCount.setText("" + rightFoul);
        leftFoulCount.setText("" + leftFoul);


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    int rightScore = 0;
    int rightFoul = 0;
    int leftScore = 0;
    int leftFoul = 0;


    public int rightscoreadder() {
        rightScore++;
        return rightScore;
    }

    public int rightscoresubtracter() {
        if (rightScore != 0) {
            rightScore--;
        } else {
            rightScore = 0;
        }
        return rightScore;
    }

    public int rightfouladder() {
        rightFoul++;
        return rightFoul;
    }

    public int rightfoulsubtracter() {
        if (rightFoul != 0) {
            rightFoul--;
        } else {
            rightFoul = 0;
        }
        return rightFoul;
    }

    public int leftscoreadder() {
        leftScore++;
        return leftScore;
    }

    public int leftscoresubtracter() {
        if (leftScore != 0) {
            leftScore--;
        } else {
            leftScore = 0;
        }
        return leftScore;
    }

    public int leftfouladder() {
        leftFoul++;
        return leftFoul;
    }

    public int leftfoulsubtracter() {
        if (leftFoul != 0) {
            leftFoul--;
        } else {
            leftFoul = 0;
        }
        return leftFoul;
    }

    public void displaySorter(View view) {

        TextView rightScoreCount = (TextView) findViewById(R.id.RightScoreCounter);
        TextView rightFoulCount = (TextView) findViewById(R.id.RightFoulCounter);
        TextView leftScoreCount = (TextView) findViewById(R.id.LeftScoreCounter);
        TextView leftFoulCount = (TextView) findViewById(R.id.LeftFoulCounter);

        if (view.equals(findViewById(R.id.RightScoreSubtract))) {
            rightScoreCount.setText("" + rightscoresubtracter());
        }
        if (view.equals(findViewById(R.id.RightScoreAdd))) {
            rightScoreCount.setText("" + rightscoreadder());
        }
        if (view.equals(findViewById(R.id.RightFoulSubtract))) {
            rightFoulCount.setText("" + rightfoulsubtracter());
        }
        if (view.equals(findViewById(R.id.RightFoulAdd))) {
            rightFoulCount.setText("" + rightfouladder());
        }
        if (view.equals(findViewById(R.id.LeftScoreSubtract))) {
            leftScoreCount.setText("" + leftscoresubtracter());
        }
        if (view.equals(findViewById(R.id.LeftScoreAdd))) {
            leftScoreCount.setText("" + leftscoreadder());
        }
        if (view.equals(findViewById(R.id.LeftFoulSubtract))) {
            leftFoulCount.setText("" + leftfoulsubtracter());
        }
        if (view.equals(findViewById(R.id.LeftFoulAdd))) {
            leftFoulCount.setText("" + leftfouladder());
        }
    }


}
